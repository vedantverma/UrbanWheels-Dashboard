
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

st.set_page_config(
    page_title="UrbanWheels Dashboard",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Load data
@st.cache_data
def load_data():
    df = pd.read_csv("hour_cleaned.csv", parse_dates=["dteday"])
    return df

df = load_data()

# Sidebar filters
st.sidebar.header("🎛️ Global Filters")
selected_years = st.sidebar.multiselect("Year(s)", sorted(df['yr'].unique()), default=sorted(df['yr'].unique()))
selected_seasons = st.sidebar.multiselect("Season(s)", df['season'].unique(), default=list(df['season'].unique()))
selected_weather = st.sidebar.multiselect("Weather Condition(s)", df['weathersit'].unique(), default=list(df['weathersit'].unique()))
working_filter = st.sidebar.selectbox("Working Day?", options=["All", "Working Day", "Holiday/Weekend"])
hour_range = st.sidebar.slider("Hour Range", 0, 23, (0, 23))
date_range = st.sidebar.date_input("Date Range", [df["dteday"].min(), df["dteday"].max()])

# Apply filters
filtered_df = df[
    (df['yr'].isin(selected_years)) &
    (df['season'].isin(selected_seasons)) &
    (df['weathersit'].isin(selected_weather)) &
    (df['hr'] >= hour_range[0]) & (df['hr'] <= hour_range[1]) &
    (df['dteday'] >= pd.to_datetime(date_range[0])) & (df['dteday'] <= pd.to_datetime(date_range[1]))
]

if working_filter == "Working Day":
    filtered_df = filtered_df[filtered_df['workingday'] == 1]
elif working_filter == "Holiday/Weekend":
    filtered_df = filtered_df[filtered_df['workingday'] == 0]

# 🚩 Top Section - Title
st.title("🚲 UrbanWheels Bike Sharing Dashboard")
st.markdown("Real-time insight into how time, weather, and user behavior affect bike demand (2011–2012)")

# Row 1 - KPIs
st.markdown("### 📌 Key Performance Indicators")
k1, k2, k3, k4 = st.columns(4)
k1.metric("📈 Total Rentals", int(filtered_df['cnt'].sum()))
k2.metric("🔥 Peak Hour", int(filtered_df.groupby('hr')['cnt'].mean().idxmax()))
reg_pct = 100 * filtered_df['registered'].sum() / filtered_df['cnt'].sum()
cas_pct = 100 * filtered_df['casual'].sum() / filtered_df['cnt'].sum()
k3.metric("🚴‍♂️ Registered Users (%)", f"{reg_pct:.1f}%")
k4.metric("🧍 Casual Users (%)", f"{cas_pct:.1f}%")

# Row 2 - Hourly & Weather Impact
st.markdown("### ⏰ Hourly Trend & 🌦️ Weather Impact")
c1, c2 = st.columns(2)

with c1:
    hourly_avg = filtered_df.groupby('hr')['cnt'].mean().reset_index()
    fig1 = px.line(hourly_avg, x='hr', y='cnt', title="Average Hourly Bike Usage", markers=True)
    st.plotly_chart(fig1, use_container_width=True)

with c2:
    fig2 = px.violin(filtered_df, x='weathersit', y='cnt', box=True, points="all",
                     title="Rental Distribution by Weather Condition")
    st.plotly_chart(fig2, use_container_width=True)

# Row 3 - Seasonal Chart & User Breakdown
st.markdown("### 📊 Seasonal Trends & 👥 User Breakdown")
c3, c4 = st.columns(2)

with c3:
    seasonal = filtered_df.groupby(['season'])[['casual', 'registered']].sum().reset_index()
    seasonal_melted = seasonal.melt(id_vars='season', value_vars=['casual', 'registered'],
                                    var_name='User Type', value_name='Total Rentals')
    fig3 = px.bar(seasonal_melted, x='season', y='Total Rentals', color='User Type',
                  barmode='group', title="Seasonal Rentals by User Type")
    st.plotly_chart(fig3, use_container_width=True)

with c4:
    total_users = filtered_df[['casual', 'registered']].sum()
    fig4 = go.Figure(data=[go.Pie(labels=total_users.index,
                                  values=total_users.values,
                                  hole=0.5)])
    fig4.update_layout(title="Overall User Type Distribution")
    st.plotly_chart(fig4, use_container_width=True)

# Row 4 - Table + Conditional Block
st.markdown("### 📄 Data Table & 🧠 Insights")

c5, c6 = st.columns([2, 1])
with c5:
    st.dataframe(filtered_df[['dteday', 'hr', 'season', 'weekday', 'weathersit', 'cnt', 'casual', 'registered']],
                 use_container_width=True)

with c6:
    st.markdown("#### 💡 Insight:")
    if "Winter" in selected_seasons and "Heavy Rain/Snow" in selected_weather:
        st.error("⚠️ Heavy winter weather detected — expect low rental activity!")
    elif "Summer" in selected_seasons:
        st.success("☀️ High summer activity — optimize fleet availability midday.")
    else:
        st.info("📊 Use the filters to uncover demand patterns across time, weather, and user types.")

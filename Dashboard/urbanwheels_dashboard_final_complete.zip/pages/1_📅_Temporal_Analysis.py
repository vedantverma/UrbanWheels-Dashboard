
import streamlit as st
import plotly.express as px

st.title("📅 Temporal Analysis")

import pandas as pd
import streamlit as st

@st.cache_data
def load_data():
    df = pd.read_csv("hour_cleaned.csv", parse_dates=["dteday"])
    return df

df = load_data()

# Sidebar filters
st.sidebar.header("🔍 Filter Data")

selected_years = st.sidebar.multiselect("Select Year(s)", sorted(df['yr'].unique()), default=sorted(df['yr'].unique()))
selected_seasons = st.sidebar.multiselect("Select Season(s)", df['season'].unique(), default=list(df['season'].unique()))
selected_weekdays = st.sidebar.multiselect("Select Weekday(s)", df['weekday'].unique(), default=list(df['weekday'].unique()))
date_range = st.sidebar.date_input("Select Date Range", [df['dteday'].min(), df['dteday'].max()])
hour_range = st.sidebar.slider("Select Hour Range", 0, 23, (0, 23))

# Apply filters
filtered_df = df[
    (df['yr'].isin(selected_years)) &
    (df['season'].isin(selected_seasons)) &
    (df['weekday'].isin(selected_weekdays)) &
    (df['dteday'] >= pd.to_datetime(date_range[0])) &
    (df['dteday'] <= pd.to_datetime(date_range[1])) &
    (df['hr'] >= hour_range[0]) & (df['hr'] <= hour_range[1])
]


# Summary
st.markdown("### 📌 Summary Insight")
st.info("Data from **{}** to **{}**. Showing {} records.".format(
    filtered_df['dteday'].min().date(),
    filtered_df['dteday'].max().date(),
    len(filtered_df)
))

# Tabs
tab1, tab2, tab3 = st.tabs(["Hourly Trends", "Weekday Patterns", "Heatmap"])

with tab1:
    hourly_avg = filtered_df.groupby("hr")["cnt"].mean().reset_index()
    fig = px.line(hourly_avg, x="hr", y="cnt", markers=True, title="Average Hourly Usage")
    st.plotly_chart(fig, use_container_width=True)

with tab2:
    weekday_avg = filtered_df.groupby("weekday")["cnt"].mean().reset_index()
    fig = px.bar(weekday_avg, x="weekday", y="cnt", title="Average Usage by Weekday")
    st.plotly_chart(fig, use_container_width=True)

with tab3:
    pivot = filtered_df.pivot_table(index="weekday", columns="hr", values="cnt", aggfunc="mean")
    st.dataframe(pivot.style.background_gradient(cmap='viridis', axis=None))

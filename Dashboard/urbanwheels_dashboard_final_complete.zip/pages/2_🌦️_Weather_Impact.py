
import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

st.title("🌦️ Weather Impact Analysis")

df = pd.read_csv("hour_cleaned.csv", parse_dates=["dteday"])

tab1, tab2 = st.tabs(["Boxplots", "Correlation Matrix"])

with tab1:
    fig, axes = plt.subplots(1, 2, figsize=(12,5))
    sns.boxplot(x="weathersit", y="cnt", data=df, ax=axes[0])
    axes[0].set_title("User Count by Weather Type")
    sns.scatterplot(x="temp", y="cnt", data=df, ax=axes[1])
    axes[1].set_title("User Count vs Temperature")
    st.pyplot(fig)

with tab2:
    corr = df[["temp", "atemp", "hum", "windspeed", "cnt"]].corr()
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.heatmap(corr, annot=True, cmap="coolwarm", ax=ax)
    st.pyplot(fig)

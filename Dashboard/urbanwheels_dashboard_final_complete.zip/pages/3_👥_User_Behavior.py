
import streamlit as st
import pandas as pd
import plotly.graph_objects as go

st.title("👥 User Behavior: Casual vs Registered")

df = pd.read_csv("hour_cleaned.csv", parse_dates=["dteday"])

hr_group = df.groupby("hr")[["casual", "registered"]].mean().reset_index()

fig = go.Figure()
fig.add_trace(go.Scatter(x=hr_group["hr"], y=hr_group["casual"],
                         mode='lines+markers', name='Casual Users'))
fig.add_trace(go.Scatter(x=hr_group["hr"], y=hr_group["registered"],
                         mode='lines+markers', name='Registered Users'))

fig.update_layout(title="Average Hourly Usage by User Type",
                  xaxis_title="Hour of Day", yaxis_title="Users",
                  hovermode="x unified")

st.plotly_chart(fig, use_container_width=True)
